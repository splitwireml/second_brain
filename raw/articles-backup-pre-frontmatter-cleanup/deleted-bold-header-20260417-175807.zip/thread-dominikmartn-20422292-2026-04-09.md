# Raw Source: Dom — 2026-04-09

**Type:** thread

**Tweet URL:** https://x.com/dominikmartn/status/2042229283234472417

**Author:** Dom (@dominikmartn)

**Date:** Thu Apr 09 13:12:58 +0000 2026

**Engagement:** RT 60 · Likes 1906

**Content length:** 159 chars (verified verbatim)

---

## Tweet


claude keeps getting progressive blur headers in swiftui wrong. so i built one that works and open sourced it.

https://t.co/kBQLJE6GTL https://t.co/dteLqONxTV
