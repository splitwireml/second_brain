# Raw Source: Guri Singh — 2026-04-05

**Type:** thread

**Tweet URL:** https://x.com/heygurisingh/status/2040715614785052929

**Author:** Guri Singh (@heygurisingh)

**Date:** Sun Apr 05 08:58:11 +0000 2026

**Engagement:** RT 181 · Likes 1819

**Content length:** 991 chars (verified verbatim)

---

## Tweet


Delete Notion. Delete your note-taking app. Delete your inbox triage tool.

A PhD researcher just replaced all of them with 8 AI agents that manage your Obsidian vault while you sleep.

100% open source. Works in any language.

You talk. The crew does the rest:

- Architect designs your vault and runs onboarding
- Scribe turns messy brain dumps into clean notes
- Sorter empties your inbox every evening
- Seeker searches your vault and answers with citations
- Connector finds hidden links between your notes
- Librarian runs weekly health audits and fixes broken links
- Transcriber turns meetings into structured notes
- Postman scans Gmail and Calendar for deadlines

And they talk to each other.

When the Transcriber processes a meeting, it alerts the Sorter. When the Postman finds a deadline, it flags the Architect.

It's a crew. Not a stack of isolated tools.

Runs 100% locally on your machine. MIT license.

Built by someone who got tired of forgetting things.

Link in reply ↓
