# Raw Source: Corey Haines — 2026-04-12

**Type:** thread

**Tweet URL:** https://x.com/coreyhainesco/status/2043456386751938584

**Author:** Corey Haines (@coreyhainesco)

**Date:** Sun Apr 12 22:29:02 +0000 2026

**Engagement:** RT 5 · Likes 59

**Content length:** 857 chars (verified verbatim)

---

## Tweet


I built a skill for Claude Code that plans your entire site architecture — page hierarchy, URL structure, navigation, and internal linking.

You tell it your site type and goals, and it maps out every page you need in a visual hierarchy, designs your URL patterns, specs out your header, footer, and sidebar navigation, and builds an internal linking strategy for SEO. It follows the 3-click rule so users can reach any important page fast, and it knows the right structure whether you're building a SaaS marketing site, a content blog, e-commerce, or docs.

Most sites grow organically until they're a mess. Starting with the right architecture saves you a painful restructure later.

It's called /site-architecture and it's part of Marketing Skills — a free, open source collection of 32 marketing skills for AI agents like Claude Code, Cursor, and Codex.
