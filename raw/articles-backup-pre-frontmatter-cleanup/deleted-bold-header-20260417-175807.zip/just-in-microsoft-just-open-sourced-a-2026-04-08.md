# Raw Source: Kanika — 2026-04-08

**Type:** x_article

**Tweet URL:** https://x.com/KanikaBK/status/2041803346345132410

**Author:** Kanika (@KanikaBK)

**Date:** Wed Apr 08 09:00:27 +0000 2026

**Engagement:** RT 370 · Likes 2570

**Content length:** 2,649 chars (verified verbatim)

---

## Full Article Text (verbatim from X)

🚨 JUST IN: MICROSOFT just open sourced a VOICE AI THAT TRANSCRIBES 60 MINUTES OF AUDIO in a single pass. 100% FREE.

It knows who spoke.
It knows when they spoke.
It knows exactly what they said.

All in one shot. No chunking. No context loss.

It's called VibeVoice.

Not a transcription tool.
Not a basic speech to text wrapper.

A frontier voice AI family with ASR, TTS, and real time streaming. All open source. All free.

Here's what it actually does 👇

VibeVoice ASR - Speech Recognition:
→ Processes 60 minutes of continuous audio in a single pass
→ Never slices audio into chunks so global context is never lost
→ Identifies WHO spoke, WHEN they spoke and WHAT they said simultaneously
→ Supports customized hotwords for domain specific accuracy
→ Works in 50+ languages natively
→ Already adopted by Hugging Face Transformers library
→ Already being built on by the open source community

BY PEOPLE WHO HAD NO IDEA THIS LEVEL OF ACCURACY WAS ALREADY FREE.

VibeVoice TTS - Text to Speech:
→ Generates up to 90 minutes of speech in a single pass
→ Supports up to 4 distinct speakers in one conversation
→ Natural turn taking and speaker consistency throughout
→ Expressive speech that captures emotional nuances
→ Supports English, Chinese and multiple other languages

VibeVoice Realtime - Streaming TTS:
→ Only 300 millisecond first audible latency
→ Streams text input in real time
→ 0.5B parameters so it actually deploys anywhere
→ Robust long form generation up to 10 minutes
→ Lightweight enough for production use today

The core innovation nobody is talking about:

Most voice AI models slice long audio into short chunks.
Every time they slice, they lose context.
Speaker tracking breaks. Semantic coherence breaks. Accuracy drops.
VibeVoice uses continuous speech tokenizers running at an ultra low frame rate of 7.5 Hz.
This preserves audio fidelity while dramatically boosting computational efficiency.

The entire 60 minutes stays in context.

Nothing gets lost. Nobody gets misidentified.

The numbers:
→ VibeVoice ASR 7B - available now on Hugging Face
→ VibeVoice Realtime 0.5B - try it on Colab right now
→ 50+ supported languages
→ 11 distinct English voice styles
→ 9 multilingual speaker voices
→ Already integrated into Hugging Face Transformers
→ Finetuning code now available

The wildest part?
A voice powered input method called Vibing just built itself on top of VibeVoice ASR.

Available on macOS and Windows right now.
The open source community is already shipping products on top of this.

100% Open Source.
Free to use. Free to fine tune. Free to build on.

🔖 Save this before your competitors find it first. 👇