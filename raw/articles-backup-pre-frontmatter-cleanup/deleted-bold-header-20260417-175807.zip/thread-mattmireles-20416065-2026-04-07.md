# Raw Source: Matt Mireles — 2026-04-07

**Type:** thread

**Tweet URL:** https://x.com/mattmireles/status/2041606508220489786

**Author:** Matt Mireles (@mattmireles)

**Date:** Tue Apr 07 19:58:17 +0000 2026

**Engagement:** RT 102 · Likes 907

**Content length:** 462 chars (verified verbatim)

---

## Tweet


Introducing...
Gemma 4 Multimodal Fine-Tuner for  Apple Silicon

- LoRA fine-tunning toolkit for Gemma LLM
- runs locally on macOS via PyTorch and Metal
- streams data from Google Cloud to your machine
- fine-tune on audio, image and text
- easy-to-use CLI wizard

If you want to fine-tune the new Gemma 4 on text, images, or audio without renting an H100 or copying a terabyte of data to your laptop, this is the only toolkit that does it all on Apple Silicon.
