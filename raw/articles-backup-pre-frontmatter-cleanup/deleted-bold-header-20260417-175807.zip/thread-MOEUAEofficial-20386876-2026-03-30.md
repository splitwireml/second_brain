# Raw Source: وزارة التربية والتعليم — 2026-03-30

**Type:** thread

**Tweet URL:** https://x.com/MOEUAEofficial/status/2038687694856020072

**Author:** وزارة التربية والتعليم (@MOEUAEofficial)

**Date:** Mon Mar 30 18:39:58 +0000 2026

**Engagement:** RT 334 · Likes 1376

**Content length:** 578 chars (verified verbatim)

---

## Tweet


تعلن وزارة التربية والتعليم استمرار التعلم عن بعد حتى يوم الجمعة الموافق 17 أبريل 2026 للطلبة والكادر التربوي والإداري في جميع الحضانات ورياض الأطفال والمدارس الحكومية والخاصة، وذلك حفاظاً على سلامة الجميع، مع إعادة تقييم الوضع أسبوعياً.

The Ministry of Education announces the continuation of distance learning until Friday, 17 April 2026, for students, as well as teaching and administrative staff, across all nurseries, kindergartens, and public and private schools nationwide to ensure the safety and wellbeing of everyone. The situation will be reviewed on a weekly basis.
