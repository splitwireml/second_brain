# Raw Source: Tekkers Foot — 2026-04-08

**Type:** thread

**Tweet URL:** https://x.com/tekkersfoot/status/2041963049389539747

**Author:** Tekkers Foot (@tekkersfoot)

**Date:** Wed Apr 08 19:35:03 +0000 2026

**Engagement:** RT 2349 · Likes 30506

**Content length:** 52 chars (verified verbatim)

---

## Tweet


Lamine Yamal is INSANE. 🤯🇪🇸

https://t.co/Zvlml6yfoI
