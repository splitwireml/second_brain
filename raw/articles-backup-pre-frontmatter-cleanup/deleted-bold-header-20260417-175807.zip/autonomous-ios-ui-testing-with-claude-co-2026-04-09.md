# Raw Source: Daniel Bernal — 2026-04-09

**Type:** x_article

**Tweet URL:** https://x.com/afterxleep/status/2042237199052124235

**Author:** Daniel Bernal (@afterxleep)

**Date:** Thu Apr 09 13:44:25 +0000 2026

**Engagement:** RT 90 · Likes 1739

**Content length:** 245 chars (verified verbatim)

**X Article title:** Autonomous iOS UI testing with Claude Code | FlowDeck

**X Article preview:** 

---

## Full Article Text (verbatim from X)

Here's Claude tapping, scrolling, finding bugs and fixing them. Testing the entire app experience on iOS. No Xcode. No manual steps.

FlowDeck gives your agent eyes on the simulator.

Post + Video: https://t.co/0bNo2SBeDs https://t.co/RzoOOCy7a0