# Raw Source: Oliver Prompts — 2026-04-13

**Type:** thread

**Tweet URL:** https://x.com/oliviscusAI/status/2043645306303050147

**Author:** Oliver Prompts (@oliviscusAI)

**Date:** Mon Apr 13 10:59:44 +0000 2026

**Engagement:** RT 163 · Likes 1062

**Content length:** 177 chars (verified verbatim)

---

## Tweet


someone just leaked a 320,000+ FREE apis on github.

real-time finance, ai, weather, crypto, sports.. all of it.

100% open source and working right now. https://t.co/TWszT6Qmoc
