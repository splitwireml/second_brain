# Raw Source: Al Mayadeen English — 2026-04-07

**Type:** thread

**Tweet URL:** https://x.com/MayadeenEnglish/status/2041405517382238482

**Author:** Al Mayadeen English (@MayadeenEnglish)

**Date:** Tue Apr 07 06:39:37 +0000 2026

**Engagement:** RT 2070 · Likes 5869

**Content length:** 386 chars (verified verbatim)

---

## Tweet


Professor Mohammad Marandi delivers a stark warning to the #UAE and its rulers, saying its alignment with "Israel" and role in the war on #Iran "will no longer be tolerated."

Marandi told #AlMayadeen that the geopolitical landscape is shifting, and the UAE should  “behave like a normal country and mind its own borders and its own business” or face serious consequences.

@s_m_marandi
