# Raw Source: NoLimit — 2026-04-05

**Type:** thread

**Tweet URL:** https://x.com/NoLimitGains/status/2040770116082692252

**Author:** NoLimit (@NoLimitGains)

**Date:** Sun Apr 05 12:34:46 +0000 2026

**Engagement:** RT 336 · Likes 5127

**Content length:** 102 chars (verified verbatim)

---

## Tweet


🚨 DONALD TRUMP JUST SAID THIS:

“Open the Fuckin' Strait, you crazy bastards.” https://t.co/Ik7vEblC5t
