# Raw Source: TravelGov — 2026-03-31

**Type:** x_article

**Tweet URL:** https://x.com/TravelGov/status/2038985841591062922

**Author:** TravelGov (@TravelGov)

**Date:** Tue Mar 31 14:24:41 +0000 2026

**Engagement:** RT 48 · Likes 152

**Content length:** 1,454 chars (verified verbatim)

**X Article title:** Security Alert – U.S. Mission to the United Arab Emirates – March 31, 2026 - U.S. Embassy & Consulate in the United Arab Emirates

**X Article preview:** 

---

## Full Article Text (verbatim from X)

United Arab Emirates: Our current travel advisory for the UAE  is at level 3: reconsider travel. It notes the ongoing risk of drone and missile attacks from Iran, and the Iranian regime’s threats to target locations, including organizations, businesses, and institutions, that are associated with the United States.
Commercial flights are operating out of international airports on a limited schedule. Tickets to many destinations, including on direct flights to the United States, are readily available. The fluctuating security environment impacts airport operating status, with closures resulting in postponed or canceled flights with little notice, and access to airports may be restricted to confirmed travelers only.
Borders with Oman and Saudi Arabia are open, and commercial flights from those countries are operating. Oman and Saudi Arabia continue to enforce visa requirements, and there have been reports of congestion and delays at border crossings.
The UAE legal system is functioning normally, and UAE immigration authorities continue to enforce exit bans. If you are subject to an exit ban, UAE authorities will not allow you to travel.
If you choose to remain in the UAE, you should be prepared to shelter in place in a secure location within your residence or other building whenever you receive a notification on your cell phone or otherwise become aware of a missile and/or drone attack in progress. 
Read more: https://t.co/cFPt4vVYuK