# Raw Source: Nav Toor — 2026-04-04

**Type:** x_article

**Tweet URL:** https://x.com/heynavtoor/status/2040339530931384792

**Author:** Nav Toor (@heynavtoor)

**Date:** Sat Apr 04 08:03:46 +0000 2026

**Engagement:** RT 51 · Likes 579

**Content length:** 29 chars (verified verbatim)

**X Article title:** GitHub - VoltAgent/awesome-design-md: A collection of DESIGN.md files inspired by popular brand design systems. Drop one into your project and let coding agents generate a matching UI. · GitHub

**X Article preview:** 

---

## Full Article Text (verbatim from X)

Repo: https://t.co/fjU8gWpXPR