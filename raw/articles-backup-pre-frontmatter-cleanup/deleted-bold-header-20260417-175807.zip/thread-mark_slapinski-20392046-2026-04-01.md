# Raw Source: Mark Slapinski — 2026-04-01

**Type:** thread

**Tweet URL:** https://x.com/mark_slapinski/status/2039204603967721739

**Author:** Mark Slapinski (@mark_slapinski)

**Date:** Wed Apr 01 04:53:58 +0000 2026

**Engagement:** RT 289 · Likes 2968

**Content length:** 112 chars (verified verbatim)

---

## Tweet


I'm going to call it now:

Trump is going to use a nuclear bomb on Iran and cancel the midterms.

Bookmark this.
