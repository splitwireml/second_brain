# Raw Source: Matt Epstein — 2026-04-05

**Type:** thread

**Tweet URL:** https://x.com/mattepstein/status/2040601096381677811

**Author:** Matt Epstein (@mattepstein)

**Date:** Sun Apr 05 01:23:08 +0000 2026

**Engagement:** RT 15 · Likes 358

**Content length:** 23 chars (verified verbatim)

---

## Tweet


https://t.co/YGpqnujZX2
