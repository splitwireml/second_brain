# Raw Source: The Spectator Index — 2026-04-03

**Type:** thread

**Tweet URL:** https://x.com/spectatorindex/status/2039985125405180179

**Author:** The Spectator Index (@spectatorindex)

**Date:** Fri Apr 03 08:35:29 +0000 2026

**Engagement:** RT 541 · Likes 3855

**Content length:** 157 chars (verified verbatim)

---

## Tweet


BREAKING: Kuwait says that power and water desalination facilities were targeted by Iranian attack, with teams now working to ensure continuity of operation.
