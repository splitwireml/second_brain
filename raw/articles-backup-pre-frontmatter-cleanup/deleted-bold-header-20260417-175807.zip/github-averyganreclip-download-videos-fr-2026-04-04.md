# Raw Source: Oliver Prompts — 2026-04-04

**Type:** x_article

**Tweet URL:** https://x.com/oliviscusAI/status/2040471345163620534

**Author:** Oliver Prompts (@oliviscusAI)

**Date:** Sat Apr 04 16:47:33 +0000 2026

**Engagement:** RT 10 · Likes 96

**Content length:** 197 chars (verified verbatim)

**X Article title:** GitHub - averygan/reclip: Download videos from almost any website. Lightweight, self-hosted media downloader with a clean web UI. · GitHub

**X Article preview:** 

---

## Full Article Text (verbatim from X)

Repo: https://t.co/ug65Tcu8Y2

If you want more practical AI gems and use cases, join our free newsletter with daily tutorials and latest news in AI: https://t.co/pFJ6vK3kcc https://t.co/694H69eDlU