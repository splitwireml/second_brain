# Raw Source: Muhammad Ayan — 2026-04-09

**Type:** thread

**Tweet URL:** https://x.com/socialwithaayan/status/2042121897463443936

**Author:** Muhammad Ayan (@socialwithaayan)

**Date:** Thu Apr 09 06:06:15 +0000 2026

**Engagement:** RT 1416 · Likes 13358

**Content length:** 1,100 chars (verified verbatim)

---

## Tweet


SOMEONE JUST KILLED EVERY SKETCHY VIDEO DOWNLOADER SITE ON THE INTERNET.

It's called ReClip. Self-hosted. Open source. Free.

Paste a link from YouTube, TikTok, Instagram, Twitter/X, or 1000+ other sites. Download as MP4 or MP3. That's it.

No ads. No popups. No trackers. No rate limits. No account. No sketchy installer.

Your machine. Your downloads. Your data.

Here is the full feature set:

-> 1000+ supported sites including YouTube, TikTok, Instagram, and Twitter/X
-> MP4 or MP3 output, your choice
-> Resolution selector before you download
-> Batch download. Paste multiple links at once.
-> Clean web UI that runs in any browser
-> Lightweight self-hosted setup

It went from 0 to 1.4K GitHub stars in 9 days.

239 forks already.

Here is why that number matters:

Every person who found a janky ad-covered downloader site in the last 10 years was waiting for this. A clean, private, self-hosted alternative that just works.

No business model built on your data. No premium tier. No upsells.

Built in HTML. MIT License. Two contributors. Ships in days.

100% Open Source. Free forever.
