# Raw Source: Bernhard Mueller — 2026-03-31

**Type:** x_article

**Tweet URL:** https://x.com/muellerberndt/status/2038961791582249435

**Author:** Bernhard Mueller (@muellerberndt)

**Date:** Tue Mar 31 12:49:07 +0000 2026

**Engagement:** RT 319 · Likes 4747

**Content length:** 227 chars (verified verbatim)

**X Article title:** GitHub - FloatingPragma/observer-patch-holography: OPH is an active research program aiming to construct a fundamental theory of physics from observer consistency. · GitHub

**X Article preview:** 

---

## Full Article Text (verbatim from X)

It doesn't matter if you have a Physics PhD or not. Make a significant contribution to one of the 5 Observer Path Holography papers and you will be added to the authors list of the Theory-of-Everything.

https://t.co/Pb6AYEtEKR