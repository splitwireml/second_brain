# Raw Source: Oliver Prompts — 2026-03-31

**Type:** thread

**Tweet URL:** https://x.com/oliviscusAI/status/2038933614658797588

**Author:** Oliver Prompts (@oliviscusAI)

**Date:** Tue Mar 31 10:57:09 +0000 2026

**Engagement:** RT 368 · Likes 4715

**Content length:** 295 chars (verified verbatim)

---

## Tweet


you can now literally ctrl+f your video footage.. 🤯

sentrysearch is an open-source tool that lets you type whatever you're looking for in a video like "red truck running a stop sign" and it instantly cuts and exports the exact clip from hours of raw mp4 files.

100% open source. fully offline.
