# Raw Source: AlienSky — 2026-04-17

**Type:** x_article

**Tweet URL:** https://x.com/AlienSkyAI/status/2045039909170188575

**Author:** AlienSky (@AlienSkyAI)

**Date:** Fri Apr 17 07:21:24 +0000 2026

**Engagement:** RT 0 · Likes 5

**Content length:** 233 chars (verified verbatim)

**X Article title:** AlienSkyQwen — MLX inference for Apple Silicon | AlienSky Research Labs

**X Article preview:** 

---

## Full Article Text (verbatim from X)

@Alibaba_Qwen For Mac users, we just released Apple Silicon kernels for Qwen3.6 (&amp; Qwen 3.5).  Upto 16x KV cache compression, and improved reasoning on MLX quantized models of Qwen.
https://t.co/J69xXtYa55 https://t.co/ODsjjAIHwb