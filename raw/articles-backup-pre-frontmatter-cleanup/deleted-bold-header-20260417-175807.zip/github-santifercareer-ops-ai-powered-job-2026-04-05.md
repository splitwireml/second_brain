# Raw Source: ℏεsam — 2026-04-05

**Type:** x_article

**Tweet URL:** https://x.com/Hesamation/status/2040820834428658008

**Author:** ℏεsam (@Hesamation)

**Date:** Sun Apr 05 15:56:18 +0000 2026

**Engagement:** RT 2260 · Likes 28080

**Content length:** 477 chars (verified verbatim)

**X Article title:** GitHub - santifer/career-ops: AI-powered job search system built on Claude Code. 14 skill modes, Go dashboard, PDF generation, batch processing. · GitHub

**X Article preview:** 

---

## Full Article Text (verbatim from X)

bro created an AI job search system for Claude Code that scored 700+ job applications and actually got him a job. 

AND IT'S NOW OPEN-SOURCE.

It scans multiple company career pages, rewrites your CV per job, and even fills application forms. The repo has:
> 14 skill modes (evaluate, scan, PDF, ...)
> Go terminal dashboard
> ATS-optimized PDF generation via Playwright
> 45+ companies pre-configured (Anthropic, OpenAI, ElevenLabs, Stripe...)

GitHub: https://t.co/PwrYBOAphi