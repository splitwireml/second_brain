# Raw Source: Termsheetinator — 2026-04-12

**Type:** thread

**Tweet URL:** https://x.com/termsheetinator/status/2043375260658200969

**Author:** Termsheetinator (@termsheetinator)

**Date:** Sun Apr 12 17:06:40 +0000 2026

**Engagement:** RT 2 · Likes 68

**Content length:** 23 chars (verified verbatim)

---

## Tweet


https://t.co/xQ37oUa8wI
