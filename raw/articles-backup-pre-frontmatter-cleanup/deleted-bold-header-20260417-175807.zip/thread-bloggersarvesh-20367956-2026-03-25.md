# Raw Source: Sarvesh Shrivastava — 2026-03-25

**Type:** thread

**Tweet URL:** https://x.com/bloggersarvesh/status/2036795618090520592

**Author:** Sarvesh Shrivastava (@bloggersarvesh)

**Date:** Wed Mar 25 13:21:31 +0000 2026

**Engagement:** RT 161 · Likes 1631

**Content length:** 23 chars (verified verbatim)

---

## Tweet


https://t.co/fTHrl4rFqG
