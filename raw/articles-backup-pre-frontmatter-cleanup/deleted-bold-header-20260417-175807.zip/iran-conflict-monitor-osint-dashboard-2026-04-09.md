# Raw Source: Patricia Marins — 2026-04-09

**Type:** x_article

**Tweet URL:** https://x.com/pati_marins64/status/2042090056089829831

**Author:** Patricia Marins (@pati_marins64)

**Date:** Thu Apr 09 03:59:44 +0000 2026

**Engagement:** RT 78 · Likes 451

**Content length:** 185 chars (verified verbatim)

**X Article title:** Iran Conflict Monitor | OSINT Dashboard

**X Article preview:** 

---

## Full Article Text (verbatim from X)

@adamcarter has created an absolutely sensational tool, and I believe it could easily be adapted to other conflicts too. It looks really versatile.
Check it out:
https://t.co/EMS3SP3Rnh