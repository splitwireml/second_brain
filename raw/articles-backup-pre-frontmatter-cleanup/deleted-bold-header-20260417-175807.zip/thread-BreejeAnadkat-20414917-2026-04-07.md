# Raw Source: Breeje Anadkat — 2026-04-07

**Type:** thread

**Tweet URL:** https://x.com/BreejeAnadkat/status/2041491743812858102

**Author:** Breeje Anadkat (@BreejeAnadkat)

**Date:** Tue Apr 07 12:22:15 +0000 2026

**Engagement:** RT 9 · Likes 312

**Content length:** 76 chars (verified verbatim)

---

## Tweet


How I created this animated ASCII-based website in 5 easy steps.

A thread 🧵
