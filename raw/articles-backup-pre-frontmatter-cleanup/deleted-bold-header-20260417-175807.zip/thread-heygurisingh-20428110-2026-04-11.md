# Raw Source: Guri Singh — 2026-04-11

**Type:** thread

**Tweet URL:** https://x.com/heygurisingh/status/2042811095703031969

**Author:** Guri Singh (@heygurisingh)

**Date:** Sat Apr 11 03:44:53 +0000 2026

**Engagement:** RT 174 · Likes 1143

**Content length:** 1,606 chars (verified verbatim)

---

## Tweet


🚨BREAKING: An open-source agentic video production system just dropped.

11 pipelines, 49 tools, and a full product ad produced for $0.69 total.

It's called OpenMontage.

And it's not a text-to-video tool.

It's a full production orchestration system where your AI coding assistant (Claude Code, Cursor, Copilot, Windsurf) becomes the director.

Describe what you want in plain language. The agent researches, scripts, generates assets, edits, and renders the final video.

Here's what the pipeline actually does:

→ Live web research first: 15-25+ searches across YouTube, Reddit, news sites before writing a single word of script
→ 12 video generation providers: Kling, Runway Gen-4, Google Veo 3, MiniMax, plus local GPU options (WAN 2.1, Hunyuan, CogVideo)
→ 8 image generation providers: FLUX, Google Imagen 4, DALL-E 3, Stable Diffusion locally
→ 4 TTS providers: ElevenLabs, Google (700+ voices), OpenAI, and Piper offline for free
→ WhisperX word-level subtitles burned in automatically
→ Remotion for React-based animated composition with spring physics, transitions, TikTok-style captions
→ Budget governance: cost estimate before execution, per-action approval above $0.50, hard cap at $10

Here's the wildest part:

One product ad. 4 AI-generated images, TTS narration, royalty-free music, word-level subtitles, Remotion data visualizations.

Total cost: $0.69. Zero manual asset work.

Works with zero API keys too. Piper narrates locally, Pexels/Pixabay provide free stock, Remotion animates everything. No spend required to start.

100% Open Source. AGPL v3 License.

(Link in the comments)
