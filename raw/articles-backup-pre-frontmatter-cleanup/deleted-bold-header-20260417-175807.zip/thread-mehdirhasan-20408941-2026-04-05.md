# Raw Source: Mehdi Hasan — 2026-04-05

**Type:** thread

**Tweet URL:** https://x.com/mehdirhasan/status/2040894175533510990

**Author:** Mehdi Hasan (@mehdirhasan)

**Date:** Sun Apr 05 20:47:44 +0000 2026

**Engagement:** RT 9106 · Likes 35302

**Content length:** 172 chars (verified verbatim)

---

## Tweet


"Do you support Israel's 'right to exist'?"

It's a 'gotcha' queston and I debunk all the BS surrounding the 'right to exist' propaganda right here: https://t.co/OuE8cGOskE
