# Raw Source: Jason Zook — 2026-04-01

**Type:** thread

**Tweet URL:** https://x.com/jasondoesstuff/status/2039444150743867561

**Author:** Jason Zook (@jasondoesstuff)

**Date:** Wed Apr 01 20:45:51 +0000 2026

**Engagement:** RT 158 · Likes 2697

**Content length:** 345 chars (verified verbatim)

---

## Tweet


Step 1: Tell Claude Code to create a "design-system.md" from your current app/project

Step 2: Tell it to install Remotion

Step 3: Tell it to make motion graphics of interactions in your app using the design system it created (I did 16:9 for YouTube b-roll).

😎💥💪

You can also tell it to mock up popular apps (like Slack in the example below).
