# Raw Source: Frederik Feldt — 2026-04-16

**Type:** thread

**Tweet URL:** https://x.com/FrederikFeldt/status/2044579854482387128

**Author:** Frederik Feldt (@FrederikFeldt)

**Date:** Thu Apr 16 00:53:18 +0000 2026

**Engagement:** RT 72 · Likes 148

**Content length:** 23 chars (verified verbatim)

---

## Tweet


https://t.co/VACbbf3HMJ
