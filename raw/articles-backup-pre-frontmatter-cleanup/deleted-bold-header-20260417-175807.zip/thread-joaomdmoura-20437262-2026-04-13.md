# Raw Source: João Moura — 2026-04-13

**Type:** thread

**Tweet URL:** https://x.com/joaomdmoura/status/2043726271449112776

**Author:** João Moura (@joaomdmoura)

**Date:** Mon Apr 13 16:21:28 +0000 2026

**Engagement:** RT 19 · Likes 239

**Content length:** 23 chars (verified verbatim)

---

## Tweet


https://t.co/rrdgtD7a3E
