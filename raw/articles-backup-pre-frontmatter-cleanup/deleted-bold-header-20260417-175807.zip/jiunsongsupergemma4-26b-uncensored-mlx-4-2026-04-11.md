# Raw Source: 송준 Jun Song — 2026-04-11

**Type:** x_article

**Tweet URL:** https://x.com/songjunkr/status/2042933072262500686

**Author:** 송준 Jun Song (@songjunkr)

**Date:** Sat Apr 11 11:49:34 +0000 2026

**Engagement:** RT 28 · Likes 440

**Content length:** 34 chars (verified verbatim)

**X Article title:** Jiunsong/supergemma4-26b-uncensored-mlx-4bit-v2 · Hugging Face

**X Article preview:** 

---

## Full Article Text (verbatim from X)

MLX (맥) 버전 https://t.co/uzv3bPk859