# Raw Source: Rian Doris — 2026-04-10

**Type:** thread

**Tweet URL:** https://x.com/RianSweetDoris/status/2042661332684837323

**Author:** Rian Doris (@RianSweetDoris)

**Date:** Fri Apr 10 17:49:47 +0000 2026

**Engagement:** RT 240 · Likes 2157

**Content length:** 23 chars (verified verbatim)

---

## Tweet


https://t.co/qI67bDW0bB
