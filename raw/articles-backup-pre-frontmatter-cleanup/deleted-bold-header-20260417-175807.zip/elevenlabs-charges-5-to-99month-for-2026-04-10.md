# Raw Source: Nav Toor — 2026-04-10

**Type:** x_article

**Tweet URL:** https://x.com/heynavtoor/status/2042518206007644457

**Author:** Nav Toor (@heynavtoor)

**Date:** Fri Apr 10 08:21:03 +0000 2026

**Engagement:** RT 619 · Likes 4625

**Content length:** 2,463 chars (verified verbatim)

---

## Full Article Text (verbatim from X)

🚨 ElevenLabs charges $5 to $99/month for AI voice cloning. Their Business plan costs $1,320/month.

 Someone open sourced a voice AI that clones any voice from a short clip. 30 languages. Studio quality. Free.

It's called VoxCPM2.

Give it a short clip of anyone's voice. It clones their accent, emotion, tone, and pacing. Then generates any speech you want in their exact voice. 48kHz studio quality.

Type "A young woman, gentle and sweet voice" and it creates that voice from scratch. No reference audio. No voice actor. No recording. You describe a voice in words. It builds it.

2 billion parameters. Trained on 2 million hours of speech. 30 languages.

One command to install: pip install voxcpm

Here's what VoxCPM2 does:

→ Voice Design: describe any voice in words. Gender, age, tone, emotion, pace. AI creates it from nothing. No reference audio needed.
→ Voice Cloning: upload a short audio clip. AI clones the voice perfectly. Timbre, accent, rhythm, pacing.
→ Controllable Cloning: clone a voice AND control the emotion. "Slightly faster, cheerful tone." Done.
→ Ultimate Cloning: provide audio + transcript. Every vocal nuance faithfully reproduced.
→ 30 languages. Arabic, Chinese, English, French, German, Hindi, Japanese, Korean, Spanish, and 21 more. No language tags needed.
→ Context-aware. It reads the text and adjusts emotion and rhythm automatically. News sounds like news. Stories sound like stories.
→ Real-time streaming. RTF as low as 0.13 on an RTX 4090. Faster than playback speed.
→ Runs on 8GB of VRAM.
→ Fine-tune with 5 to 10 minutes of your own audio using LoRA. Build a custom voice model.
→ 48kHz output. Studio quality. No external upsampler needed.

Here's the wildest part:

On the Minimax-MLS voice similarity benchmark:

→ English: VoxCPM2 scores 85.4%. ElevenLabs scores 61.3%.
→ Chinese: VoxCPM2 scores 82.5%. ElevenLabs scores 67.7%.
→ Arabic: VoxCPM2 scores 79.1%. ElevenLabs scores 70.6%.

A free, open source model is producing more realistic voice clones than a service that charges up to $1,320/month.

Professional voice actors charge $250 to $1,000+ per project. AI voice platforms charge $5 to $100/month. Recording studios charge $200/hour.

This runs on your GPU. Locally. No API costs. No per-character pricing. No subscription. Free forever.

Already hit #1 on GitHub Trending. Built by OpenBMB and Tsinghua University. 2 billion parameters. Apache 2.0 License. Free for commercial use.

100% Open Source.