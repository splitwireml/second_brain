# Raw Source: Tom Dörr — 2026-03-31

**Type:** x_article

**Tweet URL:** https://x.com/tom_doerr/status/2038920747062612391

**Author:** Tom Dörr (@tom_doerr)

**Date:** Tue Mar 31 10:06:02 +0000 2026

**Engagement:** RT 102 · Likes 1699

**Content length:** 95 chars (verified verbatim)

**X Article title:** GitHub - openfootmanager/openfootmanager: An open source soccer/football manager game · GitHub

**X Article preview:** 

---

## Full Article Text (verbatim from X)

Open source football manager in Rust and Tauri

https://t.co/phtRkSIgQw https://t.co/84SUds01Of