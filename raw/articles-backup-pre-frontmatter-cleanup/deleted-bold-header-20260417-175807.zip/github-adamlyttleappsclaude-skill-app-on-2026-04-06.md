# Raw Source: Adam Lyttle — 2026-04-06

**Type:** x_article

**Tweet URL:** https://x.com/adamlyttleapps/status/2041174925575409967

**Author:** Adam Lyttle (@adamlyttleapps)

**Date:** Mon Apr 06 15:23:20 +0000 2026

**Engagement:** RT 78 · Likes 1739

**Content length:** 468 chars (verified verbatim)

**X Article title:** GitHub - adamlyttleapps/claude-skill-app-onboarding-questionnaire: A Claude Code skill that designs and builds high-converting questionnaire-style app onboarding flows — modelled    on proven conversion patterns from top subscription apps like Mob, Headspace and Noom · GitHub

**X Article preview:** 

---

## Full Article Text (verbatim from X)

Building a high converting app onboarding flow is hard..

So I built a Claude Skill that does it for me

Instead of spending hours figuring out the right questions and pain points… now it's done in 5 minutes

Just point it at your codebase and it does the rest

Questionnaires. Custom plans. App demos. The exact strategy used by Cal AI ($1M/mo) and Mob ($100k/mo)

It's the App Onboarding Questionnaire skill and it's available on github here:
https://t.co/zinpGegRX0