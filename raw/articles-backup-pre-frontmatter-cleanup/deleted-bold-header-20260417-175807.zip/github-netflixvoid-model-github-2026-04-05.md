# Raw Source: Min Choi — 2026-04-05

**Type:** x_article

**Tweet URL:** https://x.com/minchoi/status/2040805622594097446

**Author:** Min Choi (@minchoi)

**Date:** Sun Apr 05 14:55:51 +0000 2026

**Engagement:** RT 7 · Likes 87

**Content length:** 68 chars (verified verbatim)

**X Article title:** GitHub - Netflix/void-model · GitHub

**X Article preview:** 

---

## Full Article Text (verbatim from X)

Project page: https://t.co/PQX6c6W5qk

Demo: https://t.co/pn5kClNcN9