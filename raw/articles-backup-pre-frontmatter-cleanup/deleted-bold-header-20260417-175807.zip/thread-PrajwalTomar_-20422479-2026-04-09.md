# Raw Source: Prajwal Tomar — 2026-04-09

**Type:** thread

**Tweet URL:** https://x.com/PrajwalTomar_/status/2042247977142755767

**Author:** Prajwal Tomar (@PrajwalTomar_)

**Date:** Thu Apr 09 14:27:15 +0000 2026

**Engagement:** RT 12 · Likes 127

**Content length:** 162 chars (verified verbatim)

---

## Tweet


AI can't design clean UI?

Just built a cinematic landing page with 3D mouse tracking, WebGL shaders, and scroll animations.

Here's how ↓ https://t.co/ZY21sOHnAB
