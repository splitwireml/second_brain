# Raw Source: Daniel Foley Carter — 2026-04-12

**Type:** x_article

**Tweet URL:** https://x.com/foley_seo/status/2043283332046147934

**Author:** Daniel Foley Carter (@foley_seo)

**Date:** Sun Apr 12 11:01:23 +0000 2026

**Engagement:** RT 8 · Likes 141

**Content length:** 3,001 chars (verified verbatim)

---

## Full Article Text (verbatim from X)

SEO is easy.

SEO audit:

➜ Tear down of Google Search Console Data

➜ Build segments (non brand/brand) & sub folders (product/category/service/blog)

➜ Last 3 month YoY comparison

➜ Click gap analysis

➜ Core update impact analysis & spam updates

➜ Segment of decaying pages & queries

➜ Crawl of website

➜ Match decaying pages to word count, readability, internal links

➜ Index performance analysis (dead, weak URLS etc)

➜ GA4 data integration with decayed URLS / click gap

➜ Integration of Bouce, Session, Engagement data

➜ Divide word count by consumption time, identify unhelpful content

➜ Set up another website crawl w/ GA4/GSC API & JS render

➜ Export crawl, segment by priority

➜ Render checks key pages (DOM analysis)

➜ JS functionality review (CSR/SSR/Button Events/Dynamic Content)

➜ Canonical checks (self ref, canonical child, non-value paths)

    Handling of dynamic/parameter URLS

➜ Non value path handling (meta robots/robots)

     pagination, blog taxonomies etc.

➜ JS Content/Links/Injection Events

➜ HTTP header checks & handling (3xx/4xx/5xx)

➜ HREFLANG

➜ Internal link consistency (http 200 vs internal redirects)

➜ GSC URL Inspection output dom (by page type)

➜ Title & meta export with GSC CTR data - identify weak/gaps

➜ Ensure all content accessible (sufficient link routes)

➜ Rendering & peformance analysis (CWVs, INP, CLS etc)

➜ Crawl stats review (type/bytes/freq)

➜ Robots accessibility

➜ Structured data / JSON / markup / validation

➜ Content auditing 
     NLP, quality, topical weight
     Niche compliance (YMYL)
     E-E-A-T & Integrity
     By performance & age (updated date/lastmod)
     By performance (word count/engagement time & WPM consumption)
     Query counts & query alignment (Relevance)
     Query dilution / topical dilution
     Cannibalising content
     Plagarism & Duplication checks
     Wayback update checks
     Fact-check validation
     Internal/external links
     Content query to anchor rel

➜ Link auditing
     Ref domain accruement rate
     Segment by traffic performance
     Topical trust flow review
     Link context review
     Link distribution top pages
     Anchors
     PBN/Network checks
     OBL context
     Link consolidation & domain redirect checks
     Lost link checks
     Link spam reviews
     Disavow checks

➜ Brand Trust Analysis
     Brand search volume
     Search sentiment
     Search variants
     Company details & consistency
     Trust signals (reviews, glassdor)
     Site policies
     UGC mentions

➜ User behaviour
     Engagement analysis
     Heat, click, scroll map
     Custom explorations
     Bounce rates / eng time

➜ Indexing
     Indexed vs non indexed page analysis
     Non index reason evaluation
     Clean up (crawled/discovered curr not indexed)
     Adjusted HTTP headers
     Crawl budget / log reviews

➜ SERP Impact
     AI overview / CTR review
     Counter content strategy
     Query count analysis (Devaluation vs slippage)
     Search appearances