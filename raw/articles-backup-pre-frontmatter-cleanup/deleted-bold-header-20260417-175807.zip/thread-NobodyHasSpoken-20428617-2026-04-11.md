# Raw Source: Nobody — 2026-04-11

**Type:** thread

**Tweet URL:** https://x.com/NobodyHasSpoken/status/2042861771078406552

**Author:** Nobody (@NobodyHasSpoken)

**Date:** Sat Apr 11 07:06:15 +0000 2026

**Engagement:** RT 21 · Likes 252

**Content length:** 233 chars (verified verbatim)

---

## Tweet


@om_patel5 It's 3dsvg (https://t.co/hbz30BrqGT). Free open-source browser tool that turns SVGs, text, or pixel art into interactive 3D objects you can spin, animate, and embed—no uploads or accounts needed. Matches the video exactly.
