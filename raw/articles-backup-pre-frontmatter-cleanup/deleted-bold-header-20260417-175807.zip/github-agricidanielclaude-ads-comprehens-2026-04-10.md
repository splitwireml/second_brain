# Raw Source: Ihtesham Ali — 2026-04-10

**Type:** x_article

**Tweet URL:** https://x.com/ihtesham2005/status/2042392207425225067

**Author:** Ihtesham Ali (@ihtesham2005)

**Date:** Fri Apr 10 00:00:22 +0000 2026

**Engagement:** RT 86 · Likes 1169

**Content length:** 879 chars (verified verbatim)

**X Article title:** GitHub - AgriciDaniel/claude-ads: Comprehensive paid advertising audit & optimization skill for Claude Code. 250+ checks across Google, Meta, YouTube, LinkedIn, TikTok, Microsoft & Apple Ads with weighted scoring, parallel agents, industry templates, and AI creative generation. · GitHub

**X Article preview:** 

---

## Full Article Text (verbatim from X)

I'm going to fire my ads agency because of this Claude skill.

Its called Claude Ads a free Claude Code skill that runs 190 audit checks across Google, Meta, YouTube, LinkedIn, TikTok, and Microsoft Ads with 6 parallel subagents firing simultaneously.

One command and it tears through your entire ad stack.

Google gets 74 checks.
Meta gets 46.

Everything consolidates into a single Ads Health Score with a prioritized action plan ranked by revenue impact.

The 3x Kill Rule flags any campaign running above 3x your target CPA for immediate pause. Budget sufficiency enforced per platform. Compliance runs automatically for housing, credit, finance, and healthcare.

11 industry strategy templates built in SaaS, ecommerce, B2B, healthcare, real estate, and more.

This is what I was paying $4,000 a month for.

714 stars. MIT License. 100% Opensource.

https://t.co/PxXyDIIkgw