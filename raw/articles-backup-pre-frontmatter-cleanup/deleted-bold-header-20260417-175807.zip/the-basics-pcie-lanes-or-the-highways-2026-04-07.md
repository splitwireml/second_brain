# Raw Source: Ahmad — 2026-04-07

**Type:** x_article

**Tweet URL:** https://x.com/TheAhmadOsman/status/2041380496614019157

**Author:** Ahmad (@TheAhmadOsman)

**Date:** Tue Apr 07 05:00:12 +0000 2026

**Engagement:** RT 12 · Likes 149

**Content length:** 2,842 chars (verified verbatim)

---

## Full Article Text (verbatim from X)

the basics: PCIe lanes, or the highways GPUs use for data transfer

> you've probably seen stuff like "PCIe 4.0 x16" thrown around
> in AI/Hardware/LLM build threads

so, what's PCIe actually?
> it stands for "Peripheral Component Interconnect Express"
> it's how your GPU, SSD, or any addon card
> talks (transfers data) to your CPU
> via high-speed lanes packed into your Motherboard

> "x16" = number of PCIe lanes (more lanes = more total bandwidth)
> "4.0" = the generation (each Gen doubles bandwidth per lane)  
> "PCIe" = the name of the interface standard

---

with every PCIe "Gen" generation
> speeds usually double
> > Gen 3: ~1 GB/s 
> > Gen 4: ~2 GB/s
> > Gen 5: ~4 GB/s
> > Gen 6: ~8 GB/s

each PCIe lane
> is a full-duplex wire pair
> one pair for send, one for receive

> when you plug a GPU
> into x16 Gen 4 PCIe slot
> you're assigning 16 lanes of
> Gen 4 speed for data transfer
> to and from your GPU
> that's 32 GB/s each direction

> that's also 4 times faster than your NVMe SSD btw

---

if you're curious

> Gen 3: 1 GB/s per lane
> > 16 GB/s in one direction (read OR write)
> > 32 GB/s total bandwidth (read + write, aka "full duplex")

> Gen 4: 2 GB/s per lane
> x16 slot = 32 GB/s one way
> > 64 GB/s combined (both directions)

> Gen 5: 4 GB/s per lane
> x16 slot = 64 GB/s one way
> > 128 GB/s both ways

> Gen 6: 8 GB/s per lane
> x16 slot = 128 GB/s one way
> > 256 GB/s both ways

---

why lanes (and Gen) actually matter - inference & training

> single GPU inference
> all your Tensors and model weights cross the PCIe bus
> x16 Gen 4 = 32 GB/s both ways
> drop to x8, you're at half that; x4, you're throttled hard

> single GPU training
> Dataloader and Checkpoint Writes hit the PCIe even more
> less lanes = GPU sitting around waiting for data

> multi-GPU inference
> CPU only has so many lanes to hand out

> > gaming mobos?
> > usually x16 GPU_1, but drop to x4 for GPU_2
> > this starves bandwidth, even for GPU_1

> > Threadripper Pro/Epyc?
> > full x16 to every slot - no bottlenecks

> multi-GPU training
> Gradients and Activations need to move fast between GPUs
> no NVLink? they're stuck riding pcie
> bottleneck the lanes and your "8 GPUs" run like 3
> proper x16 lanes (and preferably NVLink) actually let you scale

---

> bandwidth cheat sheet

> 4090 on Gen 4 x16 = 32 GB/s
> drop to Gen 3 x8 = 8 GB/s
> Threadripper = 72 lanes
> > 2x-4x GPUs at x16 Gen 4
> Threadripper Pro = 128 lanes
> > 4x-6x GPUs at x16 Gen 5
> Epyc Genoa = 128–160 lanes
> > 6x-10x GPUs at x16 Gen 5
> Intel i9 or AMD Ryzen? 16-24 lanes
> > 1 GPU at x16 or 2 with bottlenecks

---

next up in this series:

> Retimers, Redrivers, and all the weird stuff nobody warns you about
> Bifurcation
> Gen 3 risers
> Chipset vs CPU lanes
> PCIe Switches
> eGPU traps
> other rookie mistakes

---

—Buy a GPU, The Movement