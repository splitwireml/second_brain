# Raw Source: Levi Munneke — 2026-03-20

**Type:** x_article

**Tweet URL:** https://x.com/levikmunneke/status/2035123865463267798

**Author:** Levi Munneke (@levikmunneke)

**Date:** Fri Mar 20 22:38:34 +0000 2026

**Engagement:** RT 37 · Likes 535

**Content length:** 4,623 chars (verified verbatim)

**X Article title:** this turns claude code and google maps into a 7-figure outbound team

**X Article preview:** too many people are sending 20-50 cold emails a day.
then wondering why their calendar is empty.
here's what the operators quietly winning in 2026 are actually doing.
google maps has 265 million

---

## Full Article Text (verbatim from X)

this turns claude code and google maps into a 7-figure outbound team

too many people are sending 20-50 cold emails a day.

then wondering why their calendar is empty.

here's what the operators quietly winning in 2026 are actually doing.

google maps has 265 million business listings.

they don't receive nearly as many emails as the businesses on Apollo getting bombarded with outreach.

not because nobody wants their business.

because nobody built the machine to reach them.

claude code on a $10/mo VPS changes that completely.

here's the full system.

THE OLD WAY IS QUIETLY KILLING YOUR AGENCY

you know the cycle.

monday: motivated, scrape 50 businesses, send 40 emails

tuesday: client calls eat the day, maybe 20 go out

wednesday: problems, delivery issues, 10-15

thursday: more issues

friday: 5-10 if you're lucky

weekly total: 150 emails.

you need 10,000+ monthly touches to build a real pipeline.

you're sending 600.

the math doesn't work. it was never going to work manually.

WHAT CLAUDE CODE ACTUALLY DOES HERE

you don't need a dev.

you don't need a $5k/mo stack.

you open claude code and you say:

"build a python scraper that hits google maps for 'dentists in Austin, TX', pulls name, address, phone, website, rating, review count, then crawls each website to extract the owner contact email, outputs to CSV. (tell me which apis from rapid API to use)"

it builds it.

there are two APIs needed as well that claude with give you

1. business data finder (grabs businesses and their website)

2. website contacts finder.

you run it on a cron job at 6am every morning.

500-2,000 fresh, enriched local business leads land in your pipeline daily.

businesses that have never been touched.

owners who aren't getting 40 identical apollo exports a week.

real people with real pain outdated websites, 11 google reviews, no photos on their business profile.

you can see exactly why they need you before you write a single word of copy.

THE THREE-CHANNEL STACK

email: the volume engine

35 domains. 105 inboxes. 3 per domain.

2,000 sends/day.

sequences trigger based on what the maps data shows:

"couldn't find a website attached to your google profile so I built you a free demo, open to checking it out?"

that's not a generic email. that's a hook built from public data they posted themselves.

follow-ups at 3, 5, 8, 14 days if leads show interest but don't reply. auto-qualifies replies. books into your calendar.

linkedin: the warm layer

claude code cross-references your maps leads against linkedin.

finds the owner or founder.

you send 30-40 soft connects per day at human volume.

not pitching. building familiarity before email lands.

twitter/x: the bonus channel

monitor locals venting about slow business, bad leads, poor google visibility.

claude code keyword monitors + queues DMs.

low volume. high intent. zero competition.

THE MATH

daily touches: 1,600-1,700 across all three channels

monthly: ~50,000 targeted touches

reply rate on hyper-local + personalized cold email: 2-6%

result: 20-40 qualified discovery calls per month

at a 25% close rate and $5-10k retainers:

5-10 new clients per month.

infrastructure cost: $200-400/mo.

one closed retainer covers years of overhead.

THE SETUP (2 AFTERNOONS, NOT 2 WEEKS)

1. spin up hostinger or hetzner VPS $7-12/mo, ubuntu

2. install claude code + tmux (persistent sessions survive connection drops)

3. tailscale VPN so you access it from phone or laptop anywhere

4. prompt claude code to build your maps scraper + email enricher

5. connect output CSV to instantly or smartlead

6. set telegram bot alerts — "1,500 sent, 14 replies, 4 booked today"

7. cron job runs at 6am. you wake up to a filled pipeline.

maintenance: tweak city/keyword targets when volume dips. that's it.

THIS WEEK'S SCHEDULE

monday: VPS + claude code live

tuesday: scraper built for your top 3 service categories + cities

wednesday: enrichment pipeline + instantly integration

thursday: 200 test sends, watch deliverability

friday: linkedin cross-reference + twitter monitor active

month 2: 15-25 calls/mo baseline

month 4: predictable, compounding pipeline

most agencies will read this, nod, and keep manually googling businesses one by one.

the ones who deploy it this week will effortlessly fill their books while everyone else complains about leads drying up.

your move.

if you want the exact system  google maps scraper, 2,000 emails/day infrastructure, full multi-channel sequencing  let's talk.

DM me "MAPS" and I'll show you how we'd build it for your niche.

or book a call to be easy - cal.com/leviwelch/30min