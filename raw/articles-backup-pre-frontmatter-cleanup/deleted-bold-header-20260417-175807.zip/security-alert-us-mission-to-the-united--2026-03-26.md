# Raw Source: TravelGov — 2026-03-26

**Type:** x_article

**Tweet URL:** https://x.com/TravelGov/status/2037193535569514889

**Author:** TravelGov (@TravelGov)

**Date:** Thu Mar 26 15:42:42 +0000 2026

**Engagement:** RT 455 · Likes 1374

**Content length:** 1,528 chars (verified verbatim)

**X Article title:** Security Alert – U.S. Mission to the United Arab Emirates – March 26, 2026 - U.S. Embassy & Consulate in the United Arab Emirates

**X Article preview:** 

---

## Full Article Text (verbatim from X)

United Arab Emirates: Our current travel advisory for the UAE is at level 3: reconsider travel. If you choose to remain in the UAE, you should be prepared to shelter in place in a secure location within your residence or another safe building whenever you receive a notification on your cell phone or otherwise become aware of a missile and/or drone attack in progress. Commercial flights are operating out of international airports in the UAE on a limited schedule, with some cancellations. Tickets from the UAE to many destinations, including on direct flights to the United States, are readily available. Visit airline websites for up-to-the-minute availability. Access to airports may be restricted to confirmed travelers only.
Borders with Oman and Saudi Arabia are open, and commercial flights from those countries are operating. Oman and Saudi Arabia continue to enforce visa requirements, and there have been reports of congestion and delays at border crossings.
The UAE legal system is functioning normally, and UAE immigration authorities continue to enforce exit bans. If you are subject to an exit ban, UAE authorities will not allow you to travel. You can check the status of an exit ban through the Dubai Police app or website, or at any Dubai or Abu Dhabi police station. See our list of UAE lawyers (link in full alert) who may be able to assist you in resolving legal issues.
Routine U.S. immigrant and nonimmigrant visa services are unavailable in the UAE until further notice.
More at: https://t.co/zBDfkdpxw5