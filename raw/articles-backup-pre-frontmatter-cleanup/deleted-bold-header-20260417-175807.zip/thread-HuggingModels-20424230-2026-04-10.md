# Raw Source: Hugging Models — 2026-04-10

**Type:** thread

**Tweet URL:** https://x.com/HuggingModels/status/2042423080333770805

**Author:** Hugging Models (@HuggingModels)

**Date:** Fri Apr 10 02:03:03 +0000 2026

**Engagement:** RT 17 · Likes 158

**Content length:** 292 chars (verified verbatim)

---

## Tweet


Meet Gemma-4-E4B-Uncensored: a powerful multimodal AI that sees, hears, and speaks. It's not just another chatbot. This model processes images, audio, and text together, unlocking next-level AI interactions. The community is buzzing about its uncensored, aggressive approach to understanding.
