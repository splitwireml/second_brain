# Raw Source: Levi Munneke — 2026-03-20

**Type:** thread

**Tweet URL:** https://x.com/levikmunneke/status/2035123865463267798

**Author:** Levi Munneke (@levikmunneke)

**Date:** Fri Mar 20 22:38:34 +0000 2026

**Engagement:** RT 37 · Likes 535

**Content length:** 23 chars (verified verbatim)

---

## Tweet


https://t.co/Anq1AxNnnS
