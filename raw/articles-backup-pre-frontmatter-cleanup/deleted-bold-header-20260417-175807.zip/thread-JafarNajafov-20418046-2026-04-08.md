# Raw Source: Jafar Najafov — 2026-04-08

**Type:** thread

**Tweet URL:** https://x.com/JafarNajafov/status/2041804695505924574

**Author:** Jafar Najafov (@JafarNajafov)

**Date:** Wed Apr 08 09:05:48 +0000 2026

**Engagement:** RT 144 · Likes 1093

**Content length:** 294 chars (verified verbatim)

---

## Tweet


🚨BREAKING: Someone just open-sourced a headless browser that runs 11x faster than Chrome and uses 9x less memory.

It's called Lightpanda and it's built from scratch specifically for AI agents, scraping, and automation.

Not a Chromium fork. Not a hack. A completely new browser written in Zig.
