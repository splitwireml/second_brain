# Raw Source: Viktor Oddy — 2026-04-04

**Type:** x_article

**Tweet URL:** https://x.com/viktoroddy/status/2040462488823570813

**Author:** Viktor Oddy (@viktoroddy)

**Date:** Sat Apr 04 16:12:21 +0000 2026

**Engagement:** RT 8 · Likes 114

**Content length:** 9,854 chars (verified verbatim)

---

## Full Article Text (verbatim from X)

Access ALL prompts for stunning animated websites in one click: https://t.co/N0kni8yzNb

Create a dark, minimalist landing page for a brand called "Asme" using React, TypeScript, Tailwind CSS, Framer Motion, and Lucide React icons. The entire page has a bg-black background. The page consists of 5 sections in this order: Hero, About, Featured Video, Philosophy, Services.

FONT

Import Google Font "Instrument Serif" (italic and regular) in index.css:

@import url('https://t.co/olOb5pvtCe');
The default body font is the system/Tailwind default sans-serif. "Instrument Serif" italic is used only for specific accent words throughout the page, applied via inline style: fontFamily: "'Instrument Serif', serif", fontStyle: "italic".

LIQUID GLASS CSS (defined in index.css under @layer components)

.liquid-glass {
 background: rgba(255, 255, 255, 0.01);
 background-blend-mode: luminosity;
 backdrop-filter: blur(4px);
 -webkit-backdrop-filter: blur(4px);
 border: none;
 box-shadow: inset 0 1px 1px rgba(255, 255, 255, 0.1);
 position: relative;
 overflow: hidden;
}

.liquid-glass::before {
 content: '';
 position: absolute;
 inset: 0;
 border-radius: inherit;
 padding: 1.4px;
 background: linear-gradient(
 180deg,
 rgba(255, 255, 255, 0.45) 0%,
 rgba(255, 255, 255, 0.15) 20%,
 rgba(255, 255, 255, 0) 40%,
 rgba(255, 255, 255, 0) 60%,
 rgba(255, 255, 255, 0.15) 80%,
 rgba(255, 255, 255, 0.45) 100%
 );
 -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
 -webkit-mask-composite: xor;
 mask-composite: exclude;
 pointer-events: none;
}
This creates a frosted glass effect with a subtle gradient border. It is used on the navbar pill, email input, buttons, and overlay cards throughout the page.

SECTION 1: HERO (inline in Index.tsx)

Full viewport height (min-h-screen), black background, flex column layout.

Background video: Positioned absolute, covers the full section, shifted down with translate-y-[calc(17%+100px)], object-cover. Starts at opacity 0 and fades in over 500ms when canplay fires. Fades out over 500ms when 0.55s remain before end, then resets to 0 and replays with fade-in (custom loop with crossfade, NOT using the loop attribute -- uses ended event listener to reset currentTime to 0 and replay). The fade animation uses requestAnimationFrame for smooth opacity transitions.

Video URL: https://t.co/KcabzD1lCR
Attributes: muted, autoPlay, playsInline, preload="auto"
Navbar (z-20): A liquid-glass rounded-full pill, max-w-5xl centered, px-6 py-3. Contains:

Left: Lucide Globe icon (24px, white) + "Asme" text (white, font-semibold, text-lg). On md+, three links ("Features", "Pricing", "About") in white/80, text-sm, font-medium with hover:text-white transition.
Right: "Sign Up" plain text button (white, text-sm, font-medium) + "Login" button in a liquid-glass rounded-full pill (px-6 py-2).
Hero content (z-10): Centered vertically with flex-1, shifted up with -translate-y-[20%], text-center.

Heading: "Built for the curious" in Instrument Serif (fontFamily: "'Instrument Serif', serif"), text-5xl/md:text-6xl/lg:text-7xl, white, tracking-tight, whitespace-nowrap, mb-8.
Email input: liquid-glass rounded-full pill with pl-6 pr-2 py-2, flex row. Contains a transparent text input (placeholder "Enter your email", white text, white/40 placeholder) and a white circular button with Lucide ArrowRight icon (20px, black).
Paragraph below input: White text-sm, leading-relaxed, px-4. Text: "Stay updated with the latest news and insights. Subscribe to our newsletter today and never miss out on exciting updates."
"Manifesto" button: liquid-glass rounded-full px-8 py-3, white text-sm font-medium, hover:bg-white/5 transition.
Social icons row (z-10, bottom): Three liquid-glass rounded-full p-4 buttons with Lucide icons: Instagram, Twitter, Globe. White/80 with hover:text-white hover:bg-white/5 transitions.

SECTION 2: ABOUT SECTION (AboutSection.tsx)

Black background, pt-32 md:pt-44 pb-10 md:pb-14 px-6. Has a subtle radial gradient overlay: bg-[radial-gradient(ellipse_at_top,_rgba(255,255,255,0.03)_0%,_transparent_70%)].

Uses useInView from framer-motion with once: true, margin: "-100px".

"ABOUT US" label: white/40, text-sm, tracking-widest, uppercase. Animates from opacity 0, y:20 over 0.6s.
Main heading (mb-16 wrapper above): Large text, text-4xl/md:text-6xl/lg:text-7xl, white, leading-[1.1], tracking-tight. Reads: "Pioneering ideas for minds that create, build, and inspire." where the italicized words (ideas, create,, build,, inspire.) are in Instrument Serif italic, colored white/60. Uses <span> tags with className="not-italic text-white/60" and inline Instrument Serif italic style. "for" and "minds that" break to a new line on md+ via <br>. Animates from opacity 0, y:40 over 0.8s with 0.1s delay.

SECTION 3: FEATURED VIDEO SECTION (FeaturedVideoSection.tsx)

Black background, pt-6 md:pt-10 pb-20 md:pb-32 px-6. Max-w-6xl centered.

Uses useInView from framer-motion with once: true, margin: "-100px".

Video container: rounded-3xl overflow-hidden aspect-video. Animates from opacity 0, y:60 over 0.9s.
Video URL: https://t.co/vN3Hk6ew0N
Attributes: muted, autoPlay, loop, playsInline, preload="auto", object-cover, w-full h-full.
Gradient overlay on video: bg-gradient-to-t from-black/60 via-transparent to-transparent.
Bottom overlay content (absolute, bottom-0, p-6 md:p-10): Flex col on mobile, flex row on md+ (items-end, justify-between).
Left: liquid-glass rounded-2xl card (p-6 md:p-8, max-w-md). Contains "OUR APPROACH" label (white/50, text-xs, tracking-widest, uppercase, mb-3) and paragraph (white, text-sm/md:text-base, leading-relaxed): "We believe in the power of curiosity-driven exploration. Every project starts with a question, and every answer opens a new door to innovation."
Right: "Explore more" button, liquid-glass rounded-full px-8 py-3, white text-sm font-medium. Has framer-motion whileHover scale 1.05, whileTap scale 0.95.

SECTION 4: PHILOSOPHY SECTION (PhilosophySection.tsx)

Black background, py-28 md:py-40 px-6. Max-w-6xl centered.

Uses useInView from framer-motion with once: true, margin: "-100px".

Heading: "Innovation x Vision" where x is in Instrument Serif italic, white/40. Overall text-5xl/md:text-7xl/lg:text-8xl, white, tracking-tight, mb-16 md:mb-24. Animates from opacity 0, y:40 over 0.8s.

Two-column grid (md:grid-cols-2, gap-8 md:gap-12):

Left: Video in rounded-3xl, aspect-[4/3]. Animates from opacity 0, x:-40 over 0.8s with 0.2s delay.
Video URL: https://t.co/IZWArHknVt
Attributes: muted, autoPlay, loop, playsInline, preload="auto", object-cover, w-full h-full.
Right: Flex column, justify-center, gap-8. Animates from opacity 0, x:40 over 0.8s with 0.3s delay.
Block 1: "CHOOSE YOUR SPACE" label (white/40, text-xs, tracking-widest, uppercase, mb-4) + paragraph (white/70, text-base/md:text-lg, leading-relaxed): "Every meaningful breakthrough begins at the intersection of disciplined strategy and remarkable creative vision. We operate at that crossroads, turning bold thinking into tangible outcomes that move people and reshape industries."
Horizontal divider: w-full h-px bg-white/10
Block 2: "SHAPE THE FUTURE" label (same style) + paragraph: "We believe that the best work emerges when curiosity meets conviction. Our process is designed to uncover hidden opportunities and translate them into experiences that resonate long after the first impression."

SECTION 5: SERVICES SECTION (ServicesSection.tsx)

Black background, py-28 md:py-40 px-6. Has subtle radial gradient: bg-[radial-gradient(ellipse_at_center,_rgba(255,255,255,0.02)_0%,_transparent_60%)]. Max-w-6xl centered.

Uses useInView from framer-motion with once: true, margin: "-100px".

Header row: "What we do" (text-3xl/md:text-5xl, white, tracking-tight) on left, "Our services" (white/40, text-sm, hidden md:block) on right. Flex items-baseline justify-between, mb-16. Animates from opacity 0, y:30 over 0.7s.

Two-column card grid (gap-6 md:gap-8). Each card animates from opacity 0, y:50 over 0.8s, staggered by 0.15s.

Card 1:

Video URL: https://t.co/4nFsrS9fe3
Tag: "STRATEGY", Title: "Research & Insight", Description: "We dig deep into data, culture, and human behavior to surface the insights that drive meaningful, lasting change."
Card 2:

Video URL: https://t.co/psySESioSF
Tag: "CRAFT", Title: "Design & Execution", Description: "From concept to launch, we obsess over every detail to deliver experiences that feel effortless and look extraordinary."
Each card: group liquid-glass rounded-3xl overflow-hidden. Contains:

Video area: aspect-video, object-cover, w-full h-full. Video scales to 1.05 on group-hover over 700ms transition. Gradient overlay: bg-gradient-to-t from-black/40 to-transparent.
Content area (p-6 md:p-8):
Top row: Tag label (white/40, text-xs, tracking-widest, uppercase) + Lucide ArrowUpRight icon (16px) in a liquid-glass rounded-full p-2 circle, white/60 transitioning to white on group-hover.
Title: white, text-xl/md:text-2xl, mb-3, tracking-tight.
Description: white/50, text-sm, leading-relaxed.

TECH STACK: React 18, TypeScript, Vite, Tailwind CSS 3 with tailwindcss-animate plugin, Framer Motion, Lucide React, React Router DOM. The page uses shadcn/ui design tokens in Tailwind config but no shadcn components are used on the landing page itself.

COLOR PALETTE: Exclusively black/white with opacity variations. No accent colors. White at various opacities (white, white/80, white/70, white/60, white/50, white/40) for hierarchy. Black backgrounds with occasional ultra-subtle radial gradients (0.02-0.03 opacity white).

ANIMATION PATTERN: All sections use Framer Motion's useInView hook with once: true, margin: "-100px" to trigger scroll-based entrance animations. Elements slide up (y axis) or horizontally (x axis) while fading in, with staggered delays for sequential reveals.