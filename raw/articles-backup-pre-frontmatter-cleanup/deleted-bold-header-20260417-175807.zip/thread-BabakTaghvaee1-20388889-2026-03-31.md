# Raw Source: Babak Taghvaee - The Crisis Watch — 2026-03-31

**Type:** thread

**Tweet URL:** https://x.com/BabakTaghvaee1/status/2038888904309268572

**Author:** Babak Taghvaee - The Crisis Watch (@BabakTaghvaee1)

**Date:** Tue Mar 31 07:59:30 +0000 2026

**Engagement:** RT 66 · Likes 420

**Content length:** 774 chars (verified verbatim)

---

## Tweet


BREAKING: The IRGC Aerospace Force has launched a new wave of attacks against Dubai, with multiple explosions reported across the city just minutes ago.

According to incoming reports:

11:20–11:25 local time: 7–8 explosions reported in Al Quoz

Al Furjan: Thick smoke observed following a blast

Business Bay and Jebel Ali: Multiple heavy explosions described as unusually intense

Eyewitnesses report sequential detonations across several districts, consistent with a combined ballistic missile and one-way attack drone strike pattern seen in previous nights.

Despite the intensity, repeated attacks have led to a sense of normalization among residents, with alerts followed by explosions and then clearance messages shortly after.

#OperationEpicFury #OperationLionsRoar
