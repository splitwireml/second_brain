# Raw Source: Kyle Hessling — 2026-03-30

**Type:** thread

**Tweet URL:** https://x.com/KyleHessling1/status/2038672381850653119

**Author:** Kyle Hessling (@KyleHessling1)

**Date:** Mon Mar 30 17:39:07 +0000 2026

**Engagement:** RT 121 · Likes 1308

**Content length:** 421 chars (verified verbatim)

---

## Tweet


The Opus distilled Qwen 27B is going viral again, but everyone is promoting the old version! You MUST get the v2 version, which Jackrong currently does not have listed in his Opus Fintune collection, so no one is finding it. I discussed the improvements with v2 in my last week's test. Please go check out that post with the video, pinned on my page, if you get a second, and download the v2 here: https://t.co/tBMGR7yJVB
