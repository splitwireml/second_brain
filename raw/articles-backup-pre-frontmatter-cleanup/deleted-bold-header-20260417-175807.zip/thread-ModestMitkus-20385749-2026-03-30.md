# Raw Source: Modest Mitkus — 2026-03-30

**Type:** thread

**Tweet URL:** https://x.com/ModestMitkus/status/2038574966778839538

**Author:** Modest Mitkus (@ModestMitkus)

**Date:** Mon Mar 30 11:12:01 +0000 2026

**Engagement:** RT 42 · Likes 915

**Content length:** 274 chars (verified verbatim)

---

## Tweet


I just learned that you can slice your iOS app fees in half.

Instead of paying Apple 30%, you can pay only 15% by filling out one form.

They default you to the 30% rate (and you're a few clicks away from -15%) 😂

I'm mad and happy at the same time. https://t.co/iwdNspj0Lo
