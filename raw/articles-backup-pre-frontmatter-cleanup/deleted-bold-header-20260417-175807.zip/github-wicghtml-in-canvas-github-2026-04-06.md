# Raw Source: Vittorio Retrivi — 2026-04-06

**Type:** x_article

**Tweet URL:** https://x.com/vittorioretrivi/status/2041299652939542657

**Author:** Vittorio Retrivi (@vittorioretrivi)

**Date:** Mon Apr 06 23:38:57 +0000 2026

**Engagement:** RT 95 · Likes 1650

**Content length:** 207 chars (verified verbatim)

**X Article title:** GitHub - WICG/html-in-canvas · GitHub

**X Article preview:** 

---

## Full Article Text (verbatim from X)

In a few years, websites nominated for the Awwwards will be truly mind-blowing thanks to this HTML-in-Canvas feature.🤯 

I highly recommend trying it out -&gt; https://t.co/Id8nk5v8rw https://t.co/ulY1Gw0iBn