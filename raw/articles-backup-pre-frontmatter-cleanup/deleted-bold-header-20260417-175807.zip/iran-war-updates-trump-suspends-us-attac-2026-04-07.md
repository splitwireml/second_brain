# Raw Source: Al Jazeera Breaking News — 2026-04-07

**Type:** x_article

**Tweet URL:** https://x.com/AJENews/status/2041488824593695226

**Author:** Al Jazeera Breaking News (@AJENews)

**Date:** Tue Apr 07 12:10:39 +0000 2026

**Engagement:** RT 111 · Likes 700

**Content length:** 145 chars (verified verbatim)

**X Article title:** Iran war updates: Trump suspends US attacks, Tehran agrees to ceasefire | US-Israel war on Iran News | Al Jazeera

**X Article preview:** 

---

## Full Article Text (verbatim from X)

BREAKING: Two injured after ballistic missile strike on Sharjah telecom building

🔴 LIVE updates: https://t.co/EN4RGdXnkR https://t.co/YlnM0TjyZv