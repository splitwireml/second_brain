# Raw Source: Mario Nawfal — 2026-04-14

**Type:** thread

**Tweet URL:** https://x.com/MarioNawfal/status/2043943586392371314

**Author:** Mario Nawfal (@MarioNawfal)

**Date:** Tue Apr 14 06:45:00 +0000 2026

**Engagement:** RT 130 · Likes 609

**Content length:** 491 chars (verified verbatim)

---

## Tweet


🇮🇱 🇵🇸 An intelligence analyst warned Israeli leadership about October 7th in a document called the Jericho Wall. 

They dismissed it as "inadmissible trash."

Soldiers at border posts reported strange movements in the weeks prior. Also ignored.

Three to four hours before the attack, senior Israeli officials convened a meeting.

A general reportedly told his wife that morning: 

"Gaza is going to be destroyed."

Nobody has explained what was discussed in that room...

Source: @TCNetwork
