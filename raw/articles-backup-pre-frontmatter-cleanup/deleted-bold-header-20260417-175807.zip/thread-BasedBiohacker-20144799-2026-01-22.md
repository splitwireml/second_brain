# Raw Source: BasedBiohacker — 2026-01-22

**Type:** thread

**Tweet URL:** https://x.com/BasedBiohacker/status/2014479926959743474

**Author:** BasedBiohacker (@BasedBiohacker)

**Date:** Thu Jan 22 23:26:56 +0000 2026

**Engagement:** RT 265 · Likes 4198

**Content length:** 23 chars (verified verbatim)

---

## Tweet


https://t.co/pjvbSoGFOr
