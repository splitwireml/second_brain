# Raw Source: 0xSero — 2026-03-29

**Type:** x_article

**Tweet URL:** https://x.com/0xSero/status/2038255672404439405

**Author:** 0xSero (@0xSero)

**Date:** Sun Mar 29 14:03:15 +0000 2026

**Engagement:** RT 96 · Likes 1845

**Content length:** 156 chars (verified verbatim)

**X Article title:** nvidia/Nemotron-Cascade-2-30B-A3B · Hugging Face

**X Article preview:** 

---

## Full Article Text (verbatim from X)

This is god tier and fits on 24gb + 

It crushes everything up to 6x its size and ties with Gemini deep think and Deepseek on Math 

https://t.co/0Wwad8HZ4N