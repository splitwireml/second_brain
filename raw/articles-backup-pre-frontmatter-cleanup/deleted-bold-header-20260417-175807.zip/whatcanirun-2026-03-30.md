# Raw Source: ⁵⁄₉ — 2026-03-30

**Type:** x_article

**Tweet URL:** https://x.com/fiveoutofnine/status/2038728823861367233

**Author:** ⁵⁄₉ (@fiveoutofnine)

**Date:** Mon Mar 30 21:23:24 +0000 2026

**Engagement:** RT 128 · Likes 1656

**Content length:** 254 chars (verified verbatim)

**X Article title:** whatcani.run

**X Article preview:** 

---

## Full Article Text (verbatim from X)

Introducing https://t.co/KpvvGiStpI

Find the best local models based on real data

1. People run and submit benchmarks
2. Stats aggregated over models / devices
3. Find the best model for you

`npx whatcanirun`, fully open-source https://t.co/huOjH3zSAv