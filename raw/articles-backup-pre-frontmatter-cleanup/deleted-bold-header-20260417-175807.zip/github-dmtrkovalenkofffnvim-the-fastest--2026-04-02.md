# Raw Source: Dmitriy Kovalenko — 2026-04-02

**Type:** x_article

**Tweet URL:** https://x.com/neogoose_btw/status/2039509251174080971

**Author:** Dmitriy Kovalenko (@neogoose_btw)

**Date:** Thu Apr 02 01:04:32 +0000 2026

**Engagement:** RT 18 · Likes 279

**Content length:** 262 chars (verified verbatim)

**X Article title:** GitHub - dmtrKovalenko/fff.nvim: The fastest and the most accurate file search toolkit for AI agents, Neovim, Rust, C, and NodeJS · GitHub

**X Article preview:** 

---

## Full Article Text (verbatim from X)

The project is called fff and the sources are located here https://t.co/S9CydMn6dN 

And the demo you can try real time to find any files you can find here https://t.co/LEUslWV6c6

(it is running real VPS so it might die if ton of you will open at the same time)