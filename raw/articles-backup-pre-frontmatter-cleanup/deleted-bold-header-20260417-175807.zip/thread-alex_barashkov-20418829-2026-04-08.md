# Raw Source: Alex Barashkov — 2026-04-08

**Type:** thread

**Tweet URL:** https://x.com/alex_barashkov/status/2041882919715688480

**Author:** Alex Barashkov (@alex_barashkov)

**Date:** Wed Apr 08 14:16:39 +0000 2026

**Engagement:** RT 27 · Likes 992

**Content length:** 103 chars (verified verbatim)

---

## Tweet


Good luck getting this level of quality and precision from AI. Made in Blender. https://t.co/mbwe9Ax89P
