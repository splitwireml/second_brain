# Raw Source: Pierre-Eliott Lallemant — 2026-04-12

**Type:** thread

**Tweet URL:** https://x.com/pierreeliottlal/status/2043415994056790508

**Author:** Pierre-Eliott Lallemant (@pierreeliottlal)

**Date:** Sun Apr 12 19:48:32 +0000 2026

**Engagement:** RT 15 · Likes 141

**Content length:** 23 chars (verified verbatim)

---

## Tweet


https://t.co/71DYzkriaR
