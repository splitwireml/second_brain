# Raw Source: Martin LeBlanc — 2026-04-09

**Type:** thread

**Tweet URL:** https://x.com/martinleblanc/status/2042336586726027773

**Author:** Martin LeBlanc (@martinleblanc)

**Date:** Thu Apr 09 20:19:21 +0000 2026

**Engagement:** RT 244 · Likes 2344

**Content length:** 1,146 chars (verified verbatim)

---

## Tweet


Seedance 2 is out globally on Freepik! 🎸

And now you got to learn how to prompt for it.

So I went ahead and made a Spaces workflow for you - link below.

And here's a prompt for you to kick off:

[STYLE]

Ultra-high detail Pixar-quality cinematic animation, 8K, soft global illumination, individual hair and fur strands, realistic fabric simulation, shallow depth of field, warm cozy lighting

[FORMAT]

16:9, cinematic multi-shot scene, slow tension build

[SCENE]

Cozy bedroom at night with strong 80s personality, colorful retro posters on walls, desk with glowing computer, warm lamp.

[CHARACTERS]

A young man with short dense curly blonde hair forming soft rounded clumps, pale skin, slightly tired blue eyes, wearing a black hoodie

A golden retriever with thick light golden fur and expressive eyes.

[CAMERA SYSTEM]

Smooth cinematic camera, slow push-ins, medium and close shots, no jitter.

A scene showing the guy coding. The dog wakes up from some noise. the guy asks what's up. the dog walk to across the room to a closed closet door. noise coming from inside. the guy walks up and gets ready to open the door and calms the dog.
