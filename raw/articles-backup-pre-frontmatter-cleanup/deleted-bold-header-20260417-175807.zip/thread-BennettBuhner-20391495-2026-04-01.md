# Raw Source: BenIt Pro — 2026-04-01

**Type:** thread

**Tweet URL:** https://x.com/BennettBuhner/status/2039149516662702397

**Author:** BenIt Pro (@BennettBuhner)

**Date:** Wed Apr 01 01:15:04 +0000 2026

**Engagement:** RT 1 · Likes 202

**Content length:** 152 chars (verified verbatim)

---

## Tweet


Sorry Anthropic but I:

>forked Claude Code
>have it being refactored to Rust
>will be made open-source under “crab-code” because Rust

Sucks to suck! 🦀
