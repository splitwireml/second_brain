# Raw Source: Cheng Lou — 2026-03-28

**Type:** x_article

**Tweet URL:** https://x.com/_chenglou/status/2037715519277760531

**Author:** Cheng Lou (@_chenglou)

**Date:** Sat Mar 28 02:16:53 +0000 2026

**Engagement:** RT 195 · Likes 3949

**Content length:** 123 chars (verified verbatim)

**X Article title:** GitHub - chenglou/pretext: Fast, accurate & comprehensive text measurement & layout · GitHub

**X Article preview:** 

---

## Full Article Text (verbatim from X)

Project’s at https://t.co/meTmVhJXlk
`npm`/`bun install @chenglou/pretext` and throw your AI into making cool demos for it!