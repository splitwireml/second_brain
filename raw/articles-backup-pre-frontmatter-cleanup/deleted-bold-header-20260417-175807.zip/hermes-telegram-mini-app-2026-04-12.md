# Raw Source: mr-r0b0t — 2026-04-12

**Type:** x_article

**Tweet URL:** https://x.com/mr_r0b0t/status/2043341271561842982

**Author:** mr-r0b0t (@mr_r0b0t)

**Date:** Sun Apr 12 14:51:37 +0000 2026

**Engagement:** RT 34 · Likes 320

**Content length:** 291 chars (verified verbatim)

**X Article title:** Hermes Telegram Mini App

**X Article preview:** 

---

## Full Article Text (verbatim from X)

Hermes Telegram Mini App is now AVAILABLE OPEN SOURCE!
Can't wait to see what you all do with this, have fun 😁
For a full guide, check out the gist below before heading to the repo!
gist (guide and link to repo): https://t.co/BmfyJ98xP6
repo: https://t.co/0wWu9nHmjO
@Teknium @NousResearch 🫶