# Raw Source: Ahmad — 2026-04-03

**Type:** thread

**Tweet URL:** https://x.com/TheAhmadOsman/status/2040128469544108231

**Author:** Ahmad (@TheAhmadOsman)

**Date:** Fri Apr 03 18:05:05 +0000 2026

**Engagement:** RT 138 · Likes 1820

**Content length:** 256 chars (verified verbatim)

---

## Tweet


DROP EVERYTHING

&gt; install Harbor
&gt; harbor pull unsloth/gemma-4-31B-it-GGUF:Q4_K_M
&gt; harbor up llamacpp searxng webui
&gt; open Open WebUI
&gt; load Gemma 4

Now your local model has a UI, 
web search, and a sandboxed stack https://t.co/WQpAxtfm7n
