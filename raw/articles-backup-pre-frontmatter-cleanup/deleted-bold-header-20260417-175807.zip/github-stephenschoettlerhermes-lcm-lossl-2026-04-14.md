# Raw Source: Stephen Schoettler — 2026-04-14

**Type:** x_article

**Tweet URL:** https://x.com/SteveSchoettler/status/2043870709613768820

**Author:** Stephen Schoettler (@SteveSchoettler)

**Date:** Tue Apr 14 01:55:25 +0000 2026

**Engagement:** RT 7 · Likes 45

**Content length:** 751 chars (verified verbatim)

**X Article title:** GitHub - stephenschoettler/hermes-lcm: Lossless Context Management plugin for Hermes Agent — DAG-based context engine that never loses a message · GitHub

**X Article preview:** 

---

## Full Article Text (verbatim from X)

hermes-lcm v0.2.0 is out!

Lossless context management for Hermes Agent —  every message persisted, hierarchical DAG summaries, agent tools to drill back into anything that was compacted. No more lossy flat summaries.

What's new since launch:
  - 6 agent tools (grep, describe, expand, expand_query, status, doctor)
  - Assembly cap guardrails
  - Session filtering (ignore noisy sessions, mark others read-only)
  - Separate expansion/summarization paths
  - CI across Python 3.11-3.13
  - Stable source mapping across compaction cycles

~3,200 lines of Python. Zero dependencies. 72 tests. Drop-in plugin — just set context.engine: lcm and go.

https://t.co/8GCwp4ZMeB

Issues and PRs welcome. Already have community contributors shipping features.