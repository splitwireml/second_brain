# Raw Source: Simons — 2026-04-05

**Type:** thread

**Tweet URL:** https://x.com/Simon_Ingari/status/2040655859605553430

**Author:** Simons (@Simon_Ingari)

**Date:** Sun Apr 05 05:00:45 +0000 2026

**Engagement:** RT 189 · Likes 3786

**Content length:** 58 chars (verified verbatim)

---

## Tweet


If they put you on a PIP, send this email within 24 hours:
